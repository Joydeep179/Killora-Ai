import os, secrets, sqlite3, json, time, hashlib, hmac, ipaddress
from pathlib import Path
from collections import defaultdict, deque
from typing import Optional, Literal
import httpx
from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ConfigDict
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

ROOT=Path(__file__).resolve().parent
DATA=Path(os.getenv('DATA_DIR','/data')); DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'killora.db'; STATIC=ROOT/'static'
VERSION='1.0.1'
APP=FastAPI(title='KILLORA AI',version=VERSION,docs_url=None,redoc_url=None)
APP.mount('/static',StaticFiles(directory=STATIC),name='static')
ADMIN_USER=os.getenv('ADMIN_USERNAME','admin')
ADMIN_HASH=os.getenv('ADMIN_PASSWORD_HASH','')
# Legacy compatibility only; new installs store a scrypt hash instead.
ADMIN_PASS=os.getenv('ADMIN_PASSWORD','')
ADMIN_HASH=os.getenv('ADMIN_PASSWORD_HASH','')
API_KEY=os.getenv('KILLORA_API_KEY',''); SECRET=os.getenv('SESSION_SECRET','')
MODEL_URL=os.getenv('MODEL_API_BASE','http://inference:8080').rstrip('/')
COOKIE_SECURE=os.getenv('COOKIE_SECURE','true').lower()=='true'
serializer=URLSafeTimedSerializer(SECRET or secrets.token_hex(32),salt='killora-session')
request_buckets=defaultdict(deque)

# A small per-process abuse limiter. Nginx also applies connection/request limits.
LIMITS={'/auth/login':(8,300),'/api/chat':(20,60),'/v1/chat/completions':(30,60)}
def client_ip(request:Request):
    # Nginx is the only published entrypoint; do not trust arbitrary X-Forwarded-For chains.
    return request.client.host if request.client else 'unknown'
@APP.middleware('http')
async def security_middleware(request:Request,call_next):
    path=request.url.path
    if path in LIMITS:
        max_hits,window=LIMITS[path]; key=(client_ip(request),path); now=time.time(); q=request_buckets[key]
        while q and now-q[0]>window: q.popleft()
        if len(q)>=max_hits: return JSONResponse({'detail':'Too many requests. Please wait and try again.'},status_code=429,headers={'Retry-After':str(window)})
        q.append(now)
    if request.method in ('POST','PUT','PATCH') and request.headers.get('content-length'):
        try:
            if int(request.headers['content-length'])>2_200_000: return JSONResponse({'detail':'Request too large.'},status_code=413)
        except ValueError: return JSONResponse({'detail':'Invalid content length.'},status_code=400)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy']="default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    response.headers['Cache-Control']='no-store' if path.startswith(('/api','/auth','/v1')) else 'public, max-age=300'
    return response

def db():
    c=sqlite3.connect(DB,timeout=20); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA busy_timeout=20000'); return c

def init_db():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS datasets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT DEFAULT '',created REAL NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS examples(id INTEGER PRIMARY KEY AUTOINCREMENT,dataset_id INTEGER NOT NULL,instruction TEXT NOT NULL,input TEXT DEFAULT '',output TEXT NOT NULL,created REAL NOT NULL,FOREIGN KEY(dataset_id) REFERENCES datasets(id) ON DELETE CASCADE)")
        c.execute("CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY AUTOINCREMENT,content TEXT NOT NULL,created REAL NOT NULL)")
        c.execute('CREATE INDEX IF NOT EXISTS idx_examples_dataset ON examples(dataset_id)')
init_db()

def verify_password(password:str):
    if ADMIN_HASH:
        try:
            scheme,salt_hex,hash_hex=ADMIN_HASH.split('$',2)
            if scheme!='scrypt': return False
            got=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt_hex),n=16384,r=8,p=1,dklen=32)
            return hmac.compare_digest(got.hex(),hash_hex)
        except Exception: return False
    return bool(ADMIN_PASS) and secrets.compare_digest(password,ADMIN_PASS)

def require_session(request:Request):
    token=request.cookies.get('killora_session','')
    try:
        data=serializer.loads(token,max_age=43200)
        if data.get('u')!=ADMIN_USER: raise ValueError()
    except (BadSignature,SignatureExpired,ValueError,AttributeError): raise HTTPException(401,'Please sign in again.')

def require_api_key(auth:Optional[str]):
    token=(auth or '').removeprefix('Bearer ').strip()
    if not API_KEY or not secrets.compare_digest(token,API_KEY): raise HTTPException(401,'Invalid API key.')

class LoginBody(BaseModel): username:str=Field(min_length=1,max_length=80); password:str=Field(min_length=1,max_length=256)
class ChatBody(BaseModel):
    model_config=ConfigDict(extra='ignore')
    messages:list[dict]=Field(min_length=1,max_length=64)
    model:str='killora-ai'
    temperature:float=Field(.7,ge=0,le=2)
    max_tokens:int=Field(700,ge=1,le=4096)
    def safe_messages(self):
        allowed={'system','user','assistant','tool'}; clean=[]
        for m in self.messages:
            if not isinstance(m,dict) or m.get('role') not in allowed: raise ValueError('Invalid message role.')
            content=m.get('content','')
            if not isinstance(content,str) or len(content)>24000: raise ValueError('Message content must be text under 24,000 characters.')
            clean.append({'role':m['role'],'content':content})
        return clean
class DatasetBody(BaseModel): name:str=Field(min_length=1,max_length=80); description:str=Field(default='',max_length=500)
class ExampleBody(BaseModel): instruction:str=Field(min_length=1,max_length=12000); input:str=Field(default='',max_length=12000); output:str=Field(min_length=1,max_length=12000)
class MemoryBody(BaseModel): content:str=Field(min_length=1,max_length=2000)

@APP.get('/')
async def home(): return FileResponse(STATIC/'index.html')
@APP.post('/auth/login')
async def login(body:LoginBody):
    if not (secrets.compare_digest(body.username,ADMIN_USER) and verify_password(body.password)): raise HTTPException(401,'Incorrect username or password.')
    r=JSONResponse({'ok':True}); r.set_cookie('killora_session',serializer.dumps({'u':ADMIN_USER}),httponly=True,secure=COOKIE_SECURE,samesite='strict',max_age=43200,path='/'); return r
@APP.post('/auth/logout')
async def logout():
    r=JSONResponse({'ok':True}); r.delete_cookie('killora_session',path='/'); return r
@APP.get('/health')
async def health(): return {'status':'ok','service':'KILLORA AI','version':VERSION}
@APP.get('/api/status')
async def status(request:Request):
    require_session(request); model='offline'
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r=await client.get(MODEL_URL+'/health'); model='online' if r.is_success else 'offline'
    except Exception: pass
    with db() as c:
        ds=c.execute('SELECT COUNT(*) n FROM datasets').fetchone()['n']; ex=c.execute('SELECT COUNT(*) n FROM examples').fetchone()['n']; mem=c.execute('SELECT COUNT(*) n FROM memories').fetchone()['n']
    return {'app':'online','model':model,'version':VERSION,'datasets':ds,'examples':ex,'memories':mem}

async def forward_chat(body:ChatBody):
    try: messages=body.safe_messages()
    except ValueError as e: raise HTTPException(422,str(e))
    payload={'model':'Qwen2.5-7B-Instruct-GGUF','messages':messages,'temperature':body.temperature,'max_tokens':body.max_tokens,'stream':False}
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(300,connect=10)) as client:
            r=await client.post(MODEL_URL+'/v1/chat/completions',json=payload); r.raise_for_status(); return r.json()
    except httpx.HTTPStatusError as e: raise HTTPException(503,f'Inference returned HTTP {e.response.status_code}.')
    except Exception: raise HTTPException(503,'The local model is still downloading, starting, or unavailable. Check model logs and disk space.')
@APP.post('/api/chat')
async def browser_chat(body:ChatBody,request:Request): require_session(request); return await forward_chat(body)
@APP.get('/v1/models')
async def models(authorization:Optional[str]=Header(default=None)):
    require_api_key(authorization); return {'object':'list','data':[{'id':'killora-ai','object':'model','owned_by':'BrokenCodeZ'}]}
@APP.post('/v1/chat/completions')
async def completions(body:ChatBody,authorization:Optional[str]=Header(default=None)):
    require_api_key(authorization); return await forward_chat(body)

@APP.get('/api/training/datasets')
async def list_datasets(request:Request):
    require_session(request)
    with db() as c: rows=c.execute('SELECT d.*,COUNT(e.id) examples FROM datasets d LEFT JOIN examples e ON e.dataset_id=d.id GROUP BY d.id ORDER BY d.id DESC').fetchall()
    return [dict(x) for x in rows]
@APP.post('/api/training/datasets')
async def create_dataset(body:DatasetBody,request:Request):
    require_session(request)
    with db() as c: cur=c.execute('INSERT INTO datasets(name,description,created) VALUES(?,?,?)',(body.name.strip(),body.description,time.time())); did=cur.lastrowid
    return {'id':did,'name':body.name}
@APP.post('/api/training/datasets/{did}/examples')
async def add_example(did:int,body:ExampleBody,request:Request):
    require_session(request)
    with db() as c:
        if not c.execute('SELECT id FROM datasets WHERE id=?',(did,)).fetchone(): raise HTTPException(404,'Dataset not found.')
        cur=c.execute('INSERT INTO examples(dataset_id,instruction,input,output,created) VALUES(?,?,?,?,?)',(did,body.instruction.strip(),body.input.strip(),body.output.strip(),time.time()))
    return {'id':cur.lastrowid,'ok':True}
@APP.post('/api/training/datasets/{did}/import')
async def import_jsonl(did:int,request:Request):
    require_session(request); raw=(await request.body()).decode('utf-8-sig')
    if len(raw)>2_000_000: raise HTTPException(413,'Import limit is 2MB per request.')
    parsed=[]
    for line_no,line in enumerate(raw.splitlines(),1):
        if not line.strip(): continue
        try: row=json.loads(line)
        except Exception: raise HTTPException(400,f'Invalid JSON on line {line_no}.')
        if not isinstance(row,dict) or not row.get('instruction') or not row.get('output'): raise HTTPException(400,f'Line {line_no} needs instruction and output fields.')
        parsed.append((did,str(row['instruction'])[:12000],str(row.get('input',''))[:12000],str(row['output'])[:12000],time.time()))
        if len(parsed)>5000: raise HTTPException(413,'Maximum 5,000 examples per import.')
    if not parsed: raise HTTPException(400,'No examples found.')
    with db() as c:
        if not c.execute('SELECT id FROM datasets WHERE id=?',(did,)).fetchone(): raise HTTPException(404,'Dataset not found.')
        c.executemany('INSERT INTO examples(dataset_id,instruction,input,output,created) VALUES(?,?,?,?,?)',parsed)
    return {'imported':len(parsed)}
@APP.get('/api/training/datasets/{did}/export')
async def export_dataset(did:int,request:Request):
    require_session(request)
    with db() as c:
        d=c.execute('SELECT name FROM datasets WHERE id=?',(did,)).fetchone()
        if not d: raise HTTPException(404,'Dataset not found.')
        rows=c.execute('SELECT instruction,input,output FROM examples WHERE dataset_id=? ORDER BY id',(did,)).fetchall()
    content=''.join(json.dumps({'instruction':x['instruction'],'input':x['input'],'output':x['output']},ensure_ascii=False)+'\n' for x in rows)
    return Response(content,media_type='application/jsonl',headers={'Content-Disposition':f'attachment; filename="killora-dataset-{did}.jsonl"'})
@APP.delete('/api/training/datasets/{did}')
async def delete_dataset(did:int,request:Request):
    require_session(request)
    with db() as c: c.execute('DELETE FROM examples WHERE dataset_id=?',(did,)); c.execute('DELETE FROM datasets WHERE id=?',(did,))
    return {'ok':True}
@APP.get('/api/training/recipe')
async def training_recipe(request:Request):
    require_session(request)
    return {'method':'QLoRA supervised fine-tuning','recommended_base':'Use the original Hugging Face Transformers checkpoint for training; the 4-bit GGUF inference file is not a training checkpoint.','hardware':'This 4 vCPU / 32GB RAM CPU VPS is for inference, dataset management and evaluation preparation. Actual 7B fine-tuning requires a suitable GPU host and sufficient VRAM.','dataset_format':{'instruction':'User prompt or task','input':'Optional context','output':'Desired high-quality answer'},'config':{'method':'qlora','load_in_4bit':True,'lora_r':16,'lora_alpha':32,'lora_dropout':0.05,'epochs':2,'learning_rate':0.0002,'max_seq_length':2048,'packing':True,'evaluation_split':0.05},'workflow':['Collect licensed, high-quality examples.','Remove personal data, credentials and duplicates.','Keep a held-out evaluation split.','Run QLoRA on a GPU machine using the original Transformers checkpoint.','Evaluate safety, factuality and regressions before deploying the adapter.'],'safety':'Do not train on private data without permission. Review data rights and model licence before redistribution.'}
@APP.get('/api/memory')
async def list_memory(request:Request):
    require_session(request)
    with db() as c: return [dict(x) for x in c.execute('SELECT * FROM memories ORDER BY id DESC LIMIT 100').fetchall()]
@APP.post('/api/memory')
async def add_memory(body:MemoryBody,request:Request):
    require_session(request)
    with db() as c: cur=c.execute('INSERT INTO memories(content,created) VALUES(?,?)',(body.content.strip(),time.time()))
    return {'id':cur.lastrowid,'ok':True}
@APP.delete('/api/memory/{mid}')
async def delete_memory(mid:int,request:Request):
    require_session(request)
    with db() as c: c.execute('DELETE FROM memories WHERE id=?',(mid,))
    return {'ok':True}
