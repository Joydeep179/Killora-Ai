# KILLORA AI — Final V1 (7B)

Self-hosted AI workspace by **BrokenCodeZ**. This release uses **Qwen2.5-7B-Instruct Q4_K_M** and includes a responsive dashboard, private admin login, local llama.cpp inference, an OpenAI-compatible API, dataset management, JSONL import/export, QLoRA recipe export, Nginx, Certbot, and backup/update controls.

## Model & hardware
The selected model is `Qwen/Qwen2.5-7B-Instruct-GGUF:Q4_K_M`. Its model card lists the Q4_K_M quantization at about **4.68 GB** and an Apache-2.0 license. The VPS downloads the weights directly; they do not pass through your phone. Keep at least 12–15 GB free during install. 30–50 GB total disk is more comfortable for OS, containers, logs and backups.

A 4 vCPU / 32GB RAM CPU VPS can run a quantized 7B model, but speed varies by CPU and concurrent load. This is a single-admin V1, not a high-throughput multi-tenant inference cluster. For public multi-user traffic, add GPU inference capacity, queueing, monitoring, load testing, off-host backups, and an independent security review.

## Training Lab
Training Lab manages datasets: create collections, add examples, import/export JSONL, and export a QLoRA recipe. It does not train weights on this CPU VPS. Actual 7B fine-tuning requires the original Transformers checkpoint (not the GGUF inference file), a suitable GPU, and a training stack such as Transformers + PEFT/TRL. Evaluate data rights, privacy, safety and quality before deployment.

## Install
1. Create a public GitHub repository and upload the contents of this folder to its root.
2. Point your domain's A record to your VPS public IP. Open inbound TCP 80 and 443. DNS-only during certificate issuance is the simplest Cloudflare setup.
3. On Ubuntu 24.04, run as root:

```bash
KILLORA_REPO=https://github.com/YOUR_USERNAME/KILLORA-AI.git bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/KILLORA-AI/main/install.sh)
```

Replace `YOUR_USERNAME`. The installer asks for domain, email, admin username and password; it stores a scrypt password hash. Save the API key printed at the end.

## API
Base URL: `https://YOUR_DOMAIN/v1`; send `Authorization: Bearer YOUR_API_KEY`; model id: `killora-ai`; endpoint: `POST /v1/chat/completions`. The inference port and database are not published to the internet.

## Public deployment note
This is a hardened single-admin starter, not an audited public SaaS. Before allowing arbitrary public signups or serving many unrelated users, add multi-tenant isolation, quotas/billing if applicable, abuse reporting, privacy/terms pages, security review, load testing, monitoring and appropriately sized GPU capacity.
