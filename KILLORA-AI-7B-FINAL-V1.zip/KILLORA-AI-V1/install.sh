#!/usr/bin/env bash
set -Eeuo pipefail
DIR=/opt/killora-ai; BRANCH=${KILLORA_BRANCH:-main}; REPO=${KILLORA_REPO:-}
C='\033[0;36m'; G='\033[0;32m'; R='\033[0;31m'; N='\033[0m'
say(){ echo -e "${C}[KILLORA AI]${N} $*"; }; ok(){ echo -e "${G}[OK]${N} $*"; }; die(){ echo -e "${R}[ERROR]${N} $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die 'Run as root.'
[[ -n "$REPO" ]] || { read -rp 'GitHub repository URL (https://github.com/USER/KILLORA-AI.git): ' REPO; }
[[ "$REPO" =~ ^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(\.git)?$ ]] || die 'Enter a valid public GitHub repository URL.'
backup(){ mkdir -p /opt/killora-backups; if [[ -d "$DIR" ]]; then tar -czf "/opt/killora-backups/killora-$(date +%F-%H%M%S).tgz" --exclude='./models' --exclude='./.git' -C "$(dirname "$DIR")" "$(basename "$DIR")"; fi; }
install_deps(){ apt-get update -y; DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl git openssl nginx certbot python3-certbot-nginx python3; if ! docker compose version >/dev/null 2>&1; then DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io docker-compose-v2; fi; systemctl enable --now docker nginx; }
write_nginx(){ local domain=$1; cat >/etc/nginx/sites-available/killora-ai <<EOF
limit_req_zone \$binary_remote_addr zone=killora_limit:10m rate=10r/s;
server {
 listen 80;
 server_name $domain;
 client_max_body_size 3m;
 server_tokens off;
 limit_req_status 429;
 location / {
  limit_req zone=killora_limit burst=30 nodelay;
  proxy_pass http://127.0.0.1:3000;
  proxy_http_version 1.1;
  proxy_set_header Host \$host;
  proxy_set_header X-Real-IP \$remote_addr;
  proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
  proxy_set_header X-Forwarded-Proto \$scheme;
  proxy_read_timeout 360;
  proxy_connect_timeout 10;
 }
}
EOF
 ln -sf /etc/nginx/sites-available/killora-ai /etc/nginx/sites-enabled/killora-ai; rm -f /etc/nginx/sites-enabled/default; nginx -t; systemctl reload nginx; }
clone_source(){ TMP=$(mktemp -d); git clone --depth 1 --branch "$BRANCH" "$REPO" "$TMP/repo" || { rm -rf "$TMP"; die 'Git clone failed. Check repository URL and branch.'; }; }
copy_source(){ mkdir -p "$DIR/models" "$DIR/data"; tar -C "$TMP/repo" --exclude='./.git' -cf - . | tar -C "$DIR" -xf -; cp -a "$TMP/repo/.git" "$DIR/.git"; rm -rf "$TMP"; chmod 700 "$DIR/data" "$DIR/models"; }
install_app(){
 read -rp 'Website domain (e.g. ai.example.com): ' DOMAIN
 read -rp 'Lets Encrypt email: ' EMAIL
 read -rp 'Admin username [admin]: ' USER; USER=${USER:-admin}
 read -rsp 'Admin password (minimum 14 characters): ' PASS; echo
 [[ ${#PASS} -ge 14 ]] || die 'Use at least 14 characters.'
 [[ "$DOMAIN" =~ ^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || die 'Invalid domain.'
 [[ "$EMAIL" == *@*.* ]] || die 'Invalid email.'
 install_deps
 FREE_GB=$(df -BG / | awk 'NR==2{gsub("G","",$4);print $4}')
 (( FREE_GB >= 12 )) || die "Only ${FREE_GB}GB free. Free at least 12GB before installing the 4.68GB model and runtime."
 if [[ -d "$DIR" ]]; then backup; fi
 clone_source; copy_source
 API_KEY=$(openssl rand -hex 32); SESSION=$(openssl rand -hex 32); SALT=$(openssl rand -hex 16)
 PASS_HASH=$(python3 - "$PASS" "$SALT" <<'PYHASH'
import sys,hashlib
p=sys.argv[1].encode(); s=bytes.fromhex(sys.argv[2]); print('scrypt$'+sys.argv[2]+'$'+hashlib.scrypt(p,salt=s,n=16384,r=8,p=1,dklen=32).hex())
PYHASH
 )
 unset PASS
 cat >"$DIR/.env" <<EOF
ADMIN_USERNAME=$USER
ADMIN_PASSWORD_HASH=$PASS_HASH
KILLORA_API_KEY=$API_KEY
SESSION_SECRET=$SESSION
COOKIE_SECURE=true
EOF
 chmod 600 "$DIR/.env"
 write_nginx "$DOMAIN"
 cd "$DIR"
 say 'Starting app and downloading Qwen2.5 7B Instruct Q4_K_M directly on the VPS (~4.68GB). This uses VPS bandwidth, not phone data.'
 docker compose --profile with-model up -d --build
 say 'Requesting HTTPS. DNS must point to this VPS and inbound TCP 80/443 must be open.'
 if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect; then systemctl enable --now certbot.timer; else say 'SSL was not issued. Check DNS, Cloudflare proxy mode and inbound port 80, then retry certbot.'; fi
 ok 'KILLORA AI V1 installed.'; echo "URL: https://$DOMAIN"; echo "Admin: $USER"; echo "API key (save now): $API_KEY"; echo "App directory: $DIR"; echo 'Model: Qwen2.5-7B-Instruct Q4_K_M'; echo 'Training Lab prepares datasets and QLoRA recipes; GPU required for actual fine-tuning.'
}
update_app(){ [[ -d "$DIR/.git" ]] || die 'No Git-based installation found.'; backup; cd "$DIR"; git pull --ff-only origin "$BRANCH"; docker compose --profile with-model up -d --build; ok 'Updated. Data, models and .env were preserved.'; }
maintenance(){ [[ -d "$DIR" ]] || die 'KILLORA is not installed.'; cd "$DIR"; echo '1) Status  2) Restart app  3) App logs  4) Start model  5) Stop model  6) SSL renewal  7) Backup  8) Model logs'; read -rp 'Choose: ' x; case "$x" in
1) docker compose ps;; 2) docker compose restart app;; 3) docker compose logs --tail=120 -f app;;
4) docker compose --profile with-model up -d inference;; 5) docker compose stop inference;; 6) certbot renew --dry-run;;
7) backup; ok 'Backup saved in /opt/killora-backups.';; 8) docker compose logs --tail=120 -f inference;; *) echo 'Invalid option';; esac; }
delete_app(){ [[ -d "$DIR" ]] || die 'Not installed.'; echo '1) Remove containers only (keep all files)'; echo '2) Full removal (backup first)'; echo '3) Cancel'; read -rp 'Choose: ' x; case "$x" in
1) cd "$DIR"; docker compose --profile with-model down; ok 'Containers removed; models, database and config retained.';;
2) read -rp 'Type DELETE KILLORA to confirm: ' c; [[ "$c" == 'DELETE KILLORA' ]] || return; backup; cd "$DIR"; docker compose --profile with-model down -v || true; rm -rf "$DIR"; rm -f /etc/nginx/sites-enabled/killora-ai /etc/nginx/sites-available/killora-ai; nginx -t && systemctl reload nginx || true; ok 'Removed. A backup remains under /opt/killora-backups.';; esac; }
while true; do clear || true; echo -e "${C}KILLORA AI · FINAL V1${N}"; echo 'Developer: BrokenCodeZ'; echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'; echo '[1] Install'; echo '[2] Update'; echo '[3] Delete'; echo '[4] Maintenance'; echo '[5] Exit'; read -rp 'Select: ' c; case "$c" in 1) install_app;; 2) update_app;; 3) delete_app;; 4) maintenance;; 5) exit 0;; *) echo 'Invalid option';; esac; read -rp 'Press Enter to continue...'; done
